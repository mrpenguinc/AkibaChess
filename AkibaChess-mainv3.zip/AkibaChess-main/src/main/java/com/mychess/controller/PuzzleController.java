// ==========================================
// File: src/main/java/com/mychess/controller/PuzzleController.java
// ==========================================
package com.mychess.controller;

import chesspresso.move.Move;
import com.mychess.db.DatabaseService;
import com.mychess.model.GameModel;
import com.mychess.model.PuzzleAttempt;
import com.mychess.view.BoardPanel;
import com.mychess.view.DatabasePanel;
import com.mychess.view.PuzzlePanel;

import javax.swing.*;
import java.awt.Color;
import java.util.List;

public class PuzzleController {
    private final GameModel model;
    private final DatabaseService dbService;
    private final DatabasePanel dbPanel;
    private final PuzzlePanel puzzlePanel;
    private final BoardPanel boardPanel;
    
    private boolean active = false;
    private boolean boardLocked = false;
    
    private List<Integer> playlist;
    private int currentIndex = -1;
    
    private long puzzleStartTime;
    private int sessionCorrect = 0;
    private int sessionIncorrect = 0;
    
    private Timer sessionTimer;
    private long sessionElapsedSecs = 0;

    public PuzzleController(GameModel model, DatabaseService dbService, DatabasePanel dbPanel, PuzzlePanel puzzlePanel, BoardPanel boardPanel) {
        this.model = model;
        this.dbService = dbService;
        this.dbPanel = dbPanel;
        this.puzzlePanel = puzzlePanel;
        this.boardPanel = boardPanel;
        
        this.puzzlePanel.setNextAction(this::loadNextPuzzle);
        this.model.addMoveListener(this::onUserMoveMade);
        
        this.sessionTimer = new Timer(1000, e -> {
            sessionElapsedSecs++;
            updateSessionUI();
        });
    }

    public boolean isActive() { return active; }
    public boolean isBoardLocked() { return boardLocked; }

    public void startPuzzleMode() {
        playlist = dbPanel.getVisibleGameIds();
        if (playlist.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No games in the current database view to use as puzzles.");
            return;
        }
        
        active = true;
        currentIndex = -1;
        sessionCorrect = 0;
        sessionIncorrect = 0;
        sessionElapsedSecs = 0;
        
        sessionTimer.start();
        loadNextPuzzle();
    }

    public void stopPuzzleMode() {
        active = false;
        boardLocked = false;
        sessionTimer.stop();
        puzzlePanel.setFeedback("Puzzle Mode Stopped", Color.GRAY);
        puzzlePanel.setNextButtonEnabled(false);
        model.setClean(); // Do not trigger prompts when exiting puzzle mode after a wrong answer
    }

    private void loadNextPuzzle() {
        currentIndex++;
        if (currentIndex >= playlist.size()) {
            stopPuzzleMode();
            puzzlePanel.setFeedback("Session Complete! " + sessionCorrect + " / " + playlist.size(), new Color(0, 150, 0));
            return;
        }
        
        int dbId = playlist.get(currentIndex);
        try {
            String pgn = dbService.getGamePgn(dbId);
            model.loadPgnString(pgn, dbId);
            
            boardPanel.setFlipped(model.getGame().getPosition().getToPlay() == chesspresso.Chess.BLACK);
            
            puzzleStartTime = System.currentTimeMillis();
            boardLocked = false;
            
            List<PuzzleAttempt> history = dbService.getPuzzleAttempts(dbId);
            puzzlePanel.updateHistory(history);
            puzzlePanel.setFeedback("Your turn! Find the best move.", Color.BLUE);
            puzzlePanel.setNextButtonEnabled(false);
            updateSessionUI();
            
        } catch (Exception e) {
            puzzlePanel.setFeedback("Failed to load puzzle.", Color.RED);
            loadNextPuzzle(); 
        }
    }

    private void updateSessionUI() {
        String timeStr = String.format("%02d:%02d", sessionElapsedSecs / 60, sessionElapsedSecs % 60);
        puzzlePanel.updateSessionStats(currentIndex + 1, playlist.size(), sessionCorrect, sessionIncorrect, timeStr);
    }

    private void onUserMoveMade(boolean inTree) {
        if (!active || boardLocked) return;
        
        if (!inTree) {
            model.setClean(); // Intercept dirty flag so the wrong off-tree attempt doesn't stick
            failPuzzle("Move outside variation tree! Incorrect.");
            return;
        }
        
        checkPuzzleCompletion(true);
    }

    private void checkPuzzleCompletion(boolean userJustMoved) {
        if (model.getGame().getNextMoves().length == 0) {
            String comment = model.getGame().getComment();
            boolean failed = false;
            if (comment != null) {
                String c = comment.toLowerCase();
                if (c.contains("fail") || c.contains("wrong") || c.matches(".*\\b0\\b.*") || c.contains("incorrect")) {
                    failed = true;
                }
            }
            
            if (failed) failPuzzle("Wrong continuation! Incorrect.");
            else passPuzzle();
            
        } else if (userJustMoved) {
            triggerOpponentMove();
        }
    }

    private void triggerOpponentMove() {
        boardLocked = true;
        puzzlePanel.setFeedback("Opponent is thinking...", Color.GRAY);
        
        Timer delay = new Timer(1000, e -> {
            if (!active) return;
            Move[] nextMoves = model.getGame().getNextMoves();
            if (nextMoves.length > 0) {
                model.getGame().goForward(0); 
                model.notifyListeners();
                
                boardLocked = false;
                puzzlePanel.setFeedback("Your turn!", Color.BLUE);
                checkPuzzleCompletion(false); 
            }
        });
        delay.setRepeats(false);
        delay.start();
    }

    private void passPuzzle() {
        boardLocked = true;
        long timeTaken = System.currentTimeMillis() - puzzleStartTime;
        sessionCorrect++;
        dbService.addPuzzleAttempt(model.getCurrentDbId(), true, timeTaken);
        
        puzzlePanel.setFeedback("Correct! Next puzzle loading...", new Color(0, 150, 0));
        puzzlePanel.updateHistory(dbService.getPuzzleAttempts(model.getCurrentDbId()));
        updateSessionUI();
        
        Timer delay = new Timer(1500, e -> { if (active) loadNextPuzzle(); });
        delay.setRepeats(false);
        delay.start();
    }

    private void failPuzzle(String msg) {
        boardLocked = true;
        long timeTaken = System.currentTimeMillis() - puzzleStartTime;
        sessionIncorrect++;
        dbService.addPuzzleAttempt(model.getCurrentDbId(), false, timeTaken);
        
        puzzlePanel.setFeedback(msg, Color.RED);
        puzzlePanel.updateHistory(dbService.getPuzzleAttempts(model.getCurrentDbId()));
        puzzlePanel.setNextButtonEnabled(true);
        updateSessionUI();
    }
}