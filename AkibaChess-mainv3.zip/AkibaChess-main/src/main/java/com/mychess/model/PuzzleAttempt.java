// ==========================================
// File: src/main/java/com/mychess/model/PuzzleAttempt.java
// ==========================================
package com.mychess.model;

public class PuzzleAttempt {
    public final boolean correct;
    public final long timeMs;

    public PuzzleAttempt(boolean correct, long timeMs) {
        this.correct = correct;
        this.timeMs = timeMs;
    }
}