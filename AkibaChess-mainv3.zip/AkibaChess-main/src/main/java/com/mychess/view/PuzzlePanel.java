// ==========================================
// File: src/main/java/com/mychess/view/PuzzlePanel.java
// ==========================================
package com.mychess.view;

import com.mychess.model.PuzzleAttempt;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PuzzlePanel extends JPanel {
    private final JLabel progressLabel = new JLabel("Puzzle: - / -");
    private final JLabel timeLabel = new JLabel("Time: 00:00");
    private final JLabel scoreLabel = new JLabel("Score: 0 Correct, 0 Incorrect");
    private final JLabel feedbackLabel = new JLabel("Ready to start!");
    
    private final JPanel historyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private final JButton nextButton = new JButton("Next Puzzle");

    public PuzzlePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel statsPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        
        progressLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        timeLabel.setFont(new Font(Font.MONOSPACED, Font.BOLD, 14));
        
        statsPanel.add(progressLabel);
        statsPanel.add(timeLabel);
        statsPanel.add(scoreLabel);

        feedbackLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        feedbackLabel.setForeground(Color.GRAY);
        
        historyPanel.setBorder(BorderFactory.createTitledBorder("Attempt History for Current Puzzle"));
        
        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.add(feedbackLabel, BorderLayout.NORTH);
        centerPanel.add(historyPanel, BorderLayout.CENTER);

        nextButton.setEnabled(false);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(nextButton);

        add(statsPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public void setNextAction(Runnable action) {
        for (var al : nextButton.getActionListeners()) nextButton.removeActionListener(al);
        nextButton.addActionListener(e -> action.run());
    }

    public void setNextButtonEnabled(boolean enabled) {
        nextButton.setEnabled(enabled);
    }

    public void setFeedback(String text, Color color) {
        feedbackLabel.setText(text);
        feedbackLabel.setForeground(color);
    }

    public void updateSessionStats(int current, int total, int correct, int incorrect, String timeStr) {
        progressLabel.setText("Puzzle: " + current + " / " + total);
        scoreLabel.setText(String.format("Score: <font color='green'>%d</font> Correct, <font color='red'>%d</font> Incorrect", correct, incorrect));
        scoreLabel.setText("<html>Score: <font color='green'>" + correct + "</font> Correct, <font color='red'>" + incorrect + "</font> Incorrect</html>");
        timeLabel.setText("Time: " + timeStr);
    }

    public void updateHistory(List<PuzzleAttempt> attempts) {
        historyPanel.removeAll();
        for (PuzzleAttempt att : attempts) {
            JLabel icon = new JLabel(att.correct ? "\u2714" : "\u2718");
            icon.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
            icon.setForeground(att.correct ? new Color(0, 150, 0) : Color.RED);
            icon.setToolTipText(att.timeMs / 1000.0 + " seconds");
            historyPanel.add(icon);
        }
        historyPanel.revalidate();
        historyPanel.repaint();
    }
}