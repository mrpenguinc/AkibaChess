// ==========================================
// File: src/main/java/com/mychess/view/CommentPanel.java
// ==========================================
package com.mychess.view;

import com.mychess.model.GameModel;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class CommentPanel extends JPanel {
    private final GameModel model;
    private final JTextArea textArea;
    private final JLabel headerLabel;
    
    private boolean isUpdatingFromModel = false;
    private boolean isUpdatingToModel = false;
    private boolean editingPreComment = false;
    private boolean programmaticFocus = false;

    public CommentPanel(GameModel model) {
        this.model = model;
        this.model.addListener(this::syncFromModel);
        setLayout(new BorderLayout());

        headerLabel = new JLabel(" Comment After Move:");
        headerLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        add(headerLabel, BorderLayout.NORTH);

        textArea = new JTextArea();
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        textArea.setLineWrap(true); 
        textArea.setWrapStyleWord(true);

        textArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { updateModelSilently(); }
            @Override public void removeUpdate(DocumentEvent e) { updateModelSilently(); }
            @Override public void changedUpdate(DocumentEvent e) { updateModelSilently(); }
        });
        
        // If focus is gained naturally (mouse click or tab traversal) instead of via the right-click menu,
        // revert back to the default behavior (editing the post-move comment).
        textArea.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (!programmaticFocus && editingPreComment) {
                    editingPreComment = false;
                    syncFromModel();
                }
                programmaticFocus = false;
            }
        });

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setMinimumSize(new Dimension(150, 100));
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane, BorderLayout.CENTER);
    }

    public boolean isTextAreaFocused() { return textArea.hasFocus(); }
    
    public void focusForEdit(boolean pre) {
        programmaticFocus = true;
        editingPreComment = pre;
        syncFromModel();
        textArea.requestFocusInWindow();
    }

    private String getPre(String raw) {
        if (raw != null && raw.contains("[PRE]") && raw.contains("[/PRE]")) {
            int s = raw.indexOf("[PRE]");
            int e = raw.indexOf("[/PRE]");
            return raw.substring(s + 5, e).trim();
        }
        return "";
    }
    
    private String getPost(String raw) {
        if (raw != null && raw.contains("[PRE]") && raw.contains("[/PRE]")) {
            int e = raw.indexOf("[/PRE]");
            return raw.substring(e + 6).trim();
        }
        return raw == null ? "" : raw.trim();
    }

    private void updateModelSilently() {
        if (!isUpdatingFromModel) {
            String raw = model.getComment();
            String pre = getPre(raw);
            String post = getPost(raw);
            
            // Extract the user's raw typed text without trimming to allow typing spaces
            if (editingPreComment) {
                pre = textArea.getText();
            } else {
                post = textArea.getText();
            }
            
            StringBuilder sb = new StringBuilder();
            if (!pre.isEmpty()) {
                sb.append("[PRE]").append(pre).append("[/PRE] ");
            }
            sb.append(post);
            
            isUpdatingToModel = true; // Set flag to block cyclic UI updates
            try {
                model.setComment(sb.toString()); // Removed .trim() to stop cursor jumping
            } finally {
                isUpdatingToModel = false;
            }
        }
    }

    private void syncFromModel() {
        // Drop the update if this panel is currently the one writing to the model
        if (isUpdatingToModel) return;

        // Make sure the header always accurately reflects what we are viewing
        headerLabel.setText(editingPreComment ? " Comment Before Move:" : " Comment After Move:");
        
        String raw = model.getComment();
        String targetText = editingPreComment ? getPre(raw) : getPost(raw);
        
        if (!textArea.getText().equals(targetText)) {
            // Queue UI mutation safely so we don't interrupt a pending Document write lock
            SwingUtilities.invokeLater(() -> {
                isUpdatingFromModel = true;
                textArea.setText(targetText);
                isUpdatingFromModel = false;
            });
        }
    }
}